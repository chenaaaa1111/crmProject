/**
 * Created by admin on 2018/8/18.
 */
$(function () {
    $(".logo").on("click", function () {
        window.open("Logo.html","_self")
    });
    $(".banner").on("click", function () {
        window.open("banner.html","_self")
    });
    $(".module").on("click", function () {
        window.open("module.html","_self")
    });
    $(".footerInfo").on("click", function () {
        window.open("footerInfo.html","_self")
    });
    $(".contact").on("click", function () {
        window.open("contact.html","_self")
    });

    $(".error").on("click", function () {
        window.open("errorOther.html","_self")
    });
    $(".webbanner").on("click", function () {
        window.open("webbanner.html","_self")
    });

});