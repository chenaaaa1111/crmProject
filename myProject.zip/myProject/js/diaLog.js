$(function () {
    $('.showdialog').click(function () {
        $('.dialog').show();
    })
    $(".hidedialog").click(function () {
        $('.dialog').hide();
    })
})